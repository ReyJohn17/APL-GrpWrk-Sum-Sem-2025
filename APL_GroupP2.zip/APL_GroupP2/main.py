from flask import Flask, request, render_template_string
import io
import sys
import simplipyja_parser
import semanticAnalyzer

# OPTIONAL: Handle missing llm gracefully
try:
    import llm
    llm_available = True
except ImportError:
    llm_available = False

app = Flask(__name__)

HTML_TEMPLATE = """ 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SimpliPy-Ja Online IDE</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #f0f0f0;
        }
        .header {
            background: #3f51b5;
            color: white;
            padding: 10px 20px;
            font-size: 1.2rem;
        }
        .container {
            display: flex;
            height: calc(100vh - 48px);
        }
        .editor {
            flex: 1;
            background: white;
            display: flex;
            flex-direction: column;
        }
        .tabs {
            background: #eeeeee;
            padding: 8px 16px;
            border-bottom: 1px solid #ccc;
            font-weight: bold;
        }
        textarea {
            flex: 1;
            width: 100%;
            border: none;
            resize: none;
            font-family: monospace;
            font-size: 14px;
            padding: 12px;
            outline: none;
        }
        .output {
            flex: 1;
            background: #1e1e1e;
            color: #e0e0e0;
            padding: 16px;
            overflow-y: auto;
            font-family: monospace;
        }
        .right {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .controls {
            padding: 12px;
            border-top: 1px solid #ccc;
            background: #fafafa;
            text-align: right;
        }
        button {
            background: #3f51b5;
            color: white;
            border: none;
            padding: 8px 16px;
            font-size: 14px;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="header">SimpliPy-Ja IDE</div>
    <form method="POST">
        <div class="container">
            <div class="editor">
                <div class="tabs">code.simja</div>
                <textarea name="code" placeholder="Write your SimpliPy-Ja code here...">{{ code }}</textarea>
                <div class="controls">
                    <button type="submit">Run ▶️</button>
                </div>
            </div>
            <div class="right">
                <div class="tabs">Output</div>
                <div class="output">
                    {% if output %}
                        {{ output.replace('\\n', '<br>')|safe }}
                    {% endif %}
                    {% if explanation %}
                        <br><br><strong>LLM Explanation:</strong><br>
                        {{ explanation.replace('\\n', '<br>')|safe }}
                    {% endif %}
                </div>
            </div>
        </div>
    </form>
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def index():
    code = ""
    output = ""
    explanation = ""

    if request.method == "POST":
        code = request.form.get("code", "")
        captured_output = io.StringIO()
        sys.stdout = captured_output  # Redirect print()

        try:
            semanticAnalyzer.reset_scope()  # Clear previous variables
            simplipyja_parser.parser.parse(code)

            # Show variable values
            print("\nFinal Variables:")
            for var, val in semanticAnalyzer.symbol_table.items():
                print(f"{var} = {val}")

            # LLM explanation only if available
            if llm_available:
                explanation = llm.explain_code(code)
            else:
                explanation = "LLM module not available."

        except Exception as e:
            print(f"Error: {e}")

        sys.stdout = sys.__stdout__  # Restore print()
        output = captured_output.getvalue()

    return render_template_string(HTML_TEMPLATE, code=code, output=output, explanation=explanation)

if __name__ == "__main__":
    app.run(debug=True)
