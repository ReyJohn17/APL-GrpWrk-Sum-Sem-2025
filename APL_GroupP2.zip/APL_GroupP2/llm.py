import os
try:
    import openai
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    openai = None

def explain_code(code):
    if openai is None:
        return "LLM module not available. Install openai and python-dotenv."

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return "OpenAI API key not found. Set OPENAI_API_KEY in a .env file."

    openai.api_key = api_key

    try:
        prompt = f"Explain what this SimpliPy-Ja code does:\n{code}"
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You're helping explain SimpliPy-Ja, a Jamaican-style pseudocode language."},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        return f"LLM Error: {e}"